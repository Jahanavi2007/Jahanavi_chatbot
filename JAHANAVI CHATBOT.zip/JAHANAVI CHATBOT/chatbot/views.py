from django.http import JsonResponse
from django.shortcuts import render


# ============================================================
# Jahanavi AI CHATBOT
# Rule-Based Learning Assistant
# ============================================================


CHATBOT_RESPONSES = {

    # ========================================================
    # PYTHON
    # ========================================================

    "what is python": """
Python is a high-level programming language known for its simple
and easy-to-read syntax.

It is widely used in:
• Web Development
• Artificial Intelligence
• Machine Learning
• Data Science
• Automation
• Software Development

Example:

print("Hello World")

This simple statement prints Hello World on the screen.
""",

    "what are the features of python": """
Some important features of Python are:

• Easy and readable syntax
• High-level programming language
• Dynamically typed
• Object-oriented
• Large standard library
• Cross-platform
• Open source
• Supports multiple programming paradigms

Because of these features Python is widely used in AI
Data Science Web Development and Automation.
""",

    "why python is popular": """
Python is popular because it is easy to learn powerful
and has a huge collection of libraries and frameworks.

For example:

AI → TensorFlow PyTorch
Data Science → Pandas NumPy
Web Development → Django Flask
Visualization → Matplotlib

Its simple syntax also makes Python beginner-friendly.
""",

    "what is variable in python": """
A variable is a name used to store data in a program.

Example:

name = "Jahanavi "
age = 19

Here:

name stores a string
age stores an integer

Python automatically determines the data type of the value.
""",

    "what is list in python": """
A list is an ordered and changeable collection of items.

Example:

numbers = [10, 20, 30, 40]

You can add remove or modify elements in a list.

Example:

numbers.append(50)
""",

    "what is tuple in python": """
A tuple is an ordered collection of elements that cannot
normally be changed after creation.

Example:

numbers = (10, 20, 30)

Tuples are useful when you want to store fixed data.
""",

    "what is dictionary in python": """
A dictionary stores data in key-value pairs.

Example:

student = {
    "name": "Jahanavi ",
    "age": 19
}

Here name and age are keys and their corresponding
values are Jahanavi and 19.
""",


    # ========================================================
    # ARTIFICIAL INTELLIGENCE
    # ========================================================

    "what is ai": """
Artificial Intelligence or AI is a branch of computer science
that focuses on creating machines and software that can perform
tasks that normally require human intelligence.

Examples include:

• Voice assistants
• Recommendation systems
• Face recognition
• Chatbots
• Self-driving systems
• AI image generation

In simple words:

AI = Making machines capable of performing intelligent tasks.
""",

    "what is artificial intelligence": """
Artificial Intelligence is the ability of a computer system
or machine to perform tasks that normally require human
intelligence.

These tasks can include:

• Learning
• Reasoning
• Problem solving
• Understanding language
• Recognizing images
• Decision making

Examples include ChatGPT voice assistants recommendation
systems and face recognition systems.
""",

    "what are types of ai": """
AI can commonly be discussed in three major categories:

1. Narrow AI
Designed to perform a specific task.

2. General AI
A theoretical form of AI capable of performing a wide range
of intellectual tasks like a human.

3. Superintelligent AI
A hypothetical form of intelligence that would exceed
human intelligence in many areas.
""",

    "what is narrow ai": """
Narrow AI is an AI system designed to perform a specific
task or a limited set of tasks.

Examples:

• Face recognition
• Spam detection
• Recommendation systems
• Voice assistants

Most AI systems used today are examples of Narrow AI.
""",

    "what is machine intelligence": """
Machine intelligence refers to the ability of machines or
computer systems to perform tasks that require forms of
intelligence such as learning reasoning recognition and
decision making.
""",


    # ========================================================
    # MACHINE LEARNING
    # ========================================================

    "what is machine learning": """
Machine Learning or ML is a subset of Artificial Intelligence
that allows computers to learn patterns from data and make
predictions or decisions without being explicitly programmed
for every possible situation.

Simple example:

If we provide a machine learning model with many examples
of spam and non-spam emails it can learn patterns and predict
whether a new email is spam.
""",

    "what is ml": """
Machine Learning is a branch of Artificial Intelligence
where computers learn patterns from data and use those
patterns to make predictions or decisions.

ML is commonly divided into:

• Supervised Learning
• Unsupervised Learning
• Reinforcement Learning
""",

    "what are types of machine learning": """
The three major types of Machine Learning are:

1. Supervised Learning
The model learns from labelled data.

2. Unsupervised Learning
The model finds patterns in unlabeled data.

3. Reinforcement Learning
The model learns through rewards and penalties.
""",

    "what is supervised learning": """
Supervised Learning is a type of Machine Learning where
the model is trained using labelled data.

Example:

Input:
House size and location

Output:
House price

The model learns the relationship between the input and
known output values.
""",

    "what is unsupervised learning": """
Unsupervised Learning works with unlabeled data.

The model tries to discover hidden patterns or groups
within the data.

Example:

Customer data can be grouped into different customer
segments based on their behavior.
""",

    "what is reinforcement learning": """
Reinforcement Learning is a machine learning approach where
an agent learns by interacting with an environment.

The agent receives:

Reward → for a good action
Penalty → for an undesirable action

The goal is to learn a strategy that maximizes the total reward.
""",


    # ========================================================
    # GENERATIVE AI
    # ========================================================

    "what is generative ai": """
Generative AI is a type of Artificial Intelligence that can
create new content based on patterns learned from existing data.

It can generate:

• Text
• Images
• Audio
• Video
• Code

Examples include AI chatbots image generators and coding assistants.
""",

    "what is genai": """
Generative AI refers to AI systems that can generate new
content such as text images audio video and code.

For example:

ChatGPT → Text
Image generators → Images
Coding assistants → Code

Generative AI learns patterns from large amounts of data
and uses those patterns to create new outputs.
""",

    "what are llms": """
LLM stands for Large Language Model.

An LLM is an AI model trained on a very large amount of
text data to understand and generate human-like language.

Examples of tasks include:

• Question answering
• Summarization
• Translation
• Text generation
• Code generation
• Conversation
""",

    "what is large language model": """
A Large Language Model or LLM is an AI model designed to
understand and generate human language.

LLMs are trained using large amounts of text data and can
perform tasks such as answering questions generating text
summarizing documents translating languages and generating code.
""",


    # ========================================================
    # DEEP LEARNING
    # ========================================================

    "what is deep learning": """
Deep Learning is a subset of Machine Learning that uses
artificial neural networks with multiple layers to learn
complex patterns from data.

It is widely used in:

• Computer Vision
• Speech Recognition
• Natural Language Processing
• Image Classification
• Generative AI
""",

    "what is neural network": """
A neural network is a computational model inspired by the
structure of the human brain.

It contains interconnected nodes commonly called neurons.

A basic neural network contains:

Input Layer
Hidden Layer
Output Layer

Neural networks are widely used in Machine Learning and
Deep Learning.
""",


    # ========================================================
    # DJANGO
    # ========================================================

    "what is django": """
Django is a high-level Python web framework used to build
secure and scalable web applications.

Django follows the Model Template View architecture.

Important Django features include:

• URL routing
• Database integration
• Authentication
• Admin panel
• Templates
• Forms
• Security features

Django is built using Python.
""",

    "what is python django": """
Django is a Python-based web framework.

It provides developers with many ready-made features for
building web applications such as:

• URL routing
• Database models
• Templates
• Authentication
• Forms
• Admin interface
""",

    "what is django framework": """
Django is an open-source web framework written in Python.

It helps developers create web applications faster by
providing built-in tools for routing databases authentication
templates forms and administration.
""",

    "what is django used for": """
Django can be used to build many types of web applications.

Examples include:

• Educational platforms
• E-commerce websites
• CRM systems
• Content management systems
• REST APIs
• Dashboards
• Social platforms
• AI-powered web applications
""",


    # ========================================================
    # DATABASE
    # ========================================================

    "what is database": """
A database is an organized collection of data that can be
stored accessed managed and updated efficiently.

Examples:

• Student records
• Employee information
• Product details
• Customer information

Popular database systems include:

MySQL
PostgreSQL
Oracle
SQLite
MongoDB
""",

    "what is dbms": """
DBMS stands for Database Management System.

It is software used to create store manage retrieve and
organize data in databases.

Examples:

• MySQL
• PostgreSQL
• Oracle
• Microsoft SQL Server
""",

    "what is sql": """
SQL stands for Structured Query Language.

It is used to communicate with relational databases.

SQL can be used to:

• Create tables
• Insert data
• Retrieve data
• Update data
• Delete data

Example:

SELECT * FROM students;
""",

    "what is mysql": """
MySQL is a popular relational database management system
that uses SQL to store and manage structured data.

It is commonly used in web applications and works well
with technologies such as Python Django PHP and Java.
""",


    # ========================================================
    # DATA SCIENCE
    # ========================================================

    "what is data science": """
Data Science is a field that combines statistics programming
mathematics and machine learning to extract useful insights
from data.

A Data Scientist may work with:

• Data collection
• Data cleaning
• Data analysis
• Data visualization
• Machine Learning
• Statistical analysis
""",

    "what is pandas": """
Pandas is a popular Python library used for data manipulation
and analysis.

It provides useful data structures such as:

• Series
• DataFrame

Pandas is commonly used for cleaning analyzing filtering
and transforming datasets.
""",

    "what is numpy": """
NumPy is a Python library mainly used for numerical computing.

It provides powerful support for:

• Arrays
• Mathematical operations
• Linear algebra
• Numerical calculations

NumPy is widely used in Data Science and Machine Learning.
""",

    "what is matplotlib": """
Matplotlib is a Python library used for data visualization.

It can create:

• Line charts
• Bar charts
• Pie charts
• Histograms
• Scatter plots

It is commonly used to visualize and understand data.
""",


    # ========================================================
    # PROGRAMMING
    # ========================================================

    "what is programming": """
Programming is the process of writing instructions that
a computer can execute to solve a problem or perform a task.

Programming languages include:

• Python
• C
• C++
• Java
• JavaScript

A programmer converts a problem into a logical sequence
of instructions.
""",

    "what is algorithm": """
An algorithm is a step-by-step procedure used to solve
a particular problem.

Example:

To find the largest number:

1. Take the numbers
2. Compare them
3. Keep track of the largest value
4. Display the result
""",

    "what is data structure": """
A data structure is a way of organizing and storing data
so that it can be accessed and processed efficiently.

Examples include:

• Array
• Linked List
• Stack
• Queue
• Tree
• Graph
• Hash Table
""",


    # ========================================================
    # CHATBOT
    # ========================================================

    "what is chatbot": """
A chatbot is a software application that can communicate
with users through text or voice.

Chatbots can be:

• Rule-based
• AI-powered
• NLP-based
• LLM-powered

This Jahanavi AI chatbot currently uses predefined responses
for basic learning questions.
""",

    "how are you": """
I'm doing great and ready to help you learn 😊

You can ask me about Python AI Machine Learning
Generative AI Django databases and programming.
""",

    "hello": """
Hello 👋

I'm Jahanavi your AI Learning Assistant.

What would you like to learn today?
""",

    "hi": """
Hi 👋

Welcome to Jahanavi AI Learning Space.

You can ask me about Python AI ML Django databases
or other basic technology concepts.
""",

    "hey": """
Hey 👋

I'm ready to help you learn.

Choose a topic or ask me a question.
""",


    # ========================================================
    # Jahanavi
    # ========================================================

    "who are you": """
I'm Jahanavi.

I'm a B.Tech CSE 2nd Year student at
IIMT University Greater Noida Campus.

In this project I'm represented as an AI Learning Assistant
designed to help students understand basic technology concepts.
""",

    "who is Jahanavi": """
Jahanavi is a B.Tech CSE 2nd Year student at
IIMT University Greater Noida Campus.

This chatbot uses the Jahanavi student persona for
the learning assistant interface.
""",

    "tell me about Jahanavi ": """
Jahanavi is a B.Tech CSE 2nd Year student
at IIMT University Greater Noida Campus.

The JahanaviAI interface is designed as a student-focused
learning assistant.
""",

    "who is your mentor": """
My mentor is Suhail Malik.

He is associated with AIML training and mentoring
at IIMT University Greater Noida Campus.
""",

    "what is your name": """
My name is Jahanavi.

You can call me Jahanavi 😊
"""
}


# ============================================================
# PROFILE INFORMATION
# ============================================================

CHATBOT_PROFILE = {
    "Name": "Jahanavi",
    "Course": "B.Tech 2nd  Year",
    "Batch": "G2 ",
    "University": "IIMT University",
    "Campus": "Greater Noida",
    "Role": "AI Learning Assistant"
}


# ============================================================
# FALLBACK RESPONSE
# ============================================================

DEFAULT_RESPONSE = """
I don't have a predefined answer for that question yet.

You can try asking me about:

• Python
• Artificial Intelligence
• Machine Learning
• Generative AI
• Deep Learning
• Django
• Databases
• SQL
• Data Science
• Programming
• Chatbots

Try a simple question such as:

"What is Python?"

or

"What is Machine Learning?"
"""


# ============================================================
# HOME VIEW
# ============================================================

def home(request):
    """
    Render the main Jahanavi AI chatbot page.
    """

    context = {
        "profile": CHATBOT_PROFILE
    }

    return render(
        request,
        "chatbot/index.html",
        context
    )


# ============================================================
# CHAT VIEW
# ============================================================

def chat(request):
    """
    Process chatbot messages and return JSON response.
    """

    if request.method != "POST":

        return JsonResponse(
            {
                "response": "Please send a message using the chat interface."
            },
            status=405
        )


    message = request.POST.get("message", "")


    # --------------------------------------------------------
    # Normalize user message
    # --------------------------------------------------------

    normalized_message = message.lower().strip()


    # Remove common punctuation

    punctuation = [
        "?",
        "!",
        ".",
        ",",
        ";",
        ":"
    ]


    for symbol in punctuation:
        normalized_message = normalized_message.replace(
            symbol,
            ""
        )


    # Remove extra spaces

    normalized_message = " ".join(
        normalized_message.split()
    )


    # --------------------------------------------------------
    # Empty message
    # --------------------------------------------------------

    if not normalized_message:

        return JsonResponse(
            {
                "response": "Please type a question first 😊"
            }
        )


    # --------------------------------------------------------
    # Find predefined response
    # --------------------------------------------------------

    response = CHATBOT_RESPONSES.get(
        normalized_message,
        DEFAULT_RESPONSE
    )


    # --------------------------------------------------------
    # Return JSON
    # --------------------------------------------------------

    return JsonResponse(
        {
            "response": response
        }
    )