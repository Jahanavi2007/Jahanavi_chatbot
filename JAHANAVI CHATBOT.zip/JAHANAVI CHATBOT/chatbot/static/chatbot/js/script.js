/* =========================================================
   JahanaviAI CHATBOT
   FRONTEND SCRIPT
   ========================================================= */


/* =========================================================
   RELATED QUESTIONS
   ========================================================= */

const relatedQuestions = {

    python: [
        "What are the features of Python?",
        "Why is Python popular?",
        "What is a variable in Python?",
        "What is a list in Python?"
    ],

    ai: [
        "What are types of AI?",
        "What is Narrow AI?",
        "What is Machine Intelligence?",
        "What is Machine Learning?"
    ],

    ml: [
        "What are types of Machine Learning?",
        "What is Supervised Learning?",
        "What is Unsupervised Learning?",
        "What is Reinforcement Learning?"
    ],

    generative: [
        "What is an LLM?",
        "What is a Large Language Model?",
        "What can Generative AI create?",
        "What is Generative AI?"
    ],

    django: [
        "What is Django Framework?",
        "What is Python Django?",
        "What is Django used for?",
        "Why is Django popular?"
    ],

    database: [
        "What is DBMS?",
        "What is SQL?",
        "What is MySQL?",
        "What is a database?"
    ],

    data: [
        "What is Data Science?",
        "What is Pandas?",
        "What is NumPy?",
        "What is Matplotlib?"
    ],

    programming: [
        "What is Programming?",
        "What is an Algorithm?",
        "What is a Data Structure?",
        "What is Python?"
    ],

    chatbot: [
        "What is a Chatbot?",
        "How are chatbots created?",
        "What is Artificial Intelligence?",
        "What is Generative AI?"
    ],

    Jahanavi : [
        "Who is Jahanavi?",
        "Who is your mentor?",
        "What is AI?",
        "What is Python?"
    ]

};


/* =========================================================
   DOM ELEMENTS
   ========================================================= */

let chatBox;
let userInput;

let isSending = false;


/* =========================================================
   INITIALIZE
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    chatBox = document.getElementById("chat-box");

    userInput = document.getElementById("user-input");


    if (!chatBox || !userInput) {
        console.error("JahanaviAI: Required elements not found.");
        return;
    }


    /* -----------------------------------------------------
       ENTER TO SEND
       ----------------------------------------------------- */

    userInput.addEventListener("keydown", function (event) {

        if (event.key === "Enter" && !event.shiftKey) {

            event.preventDefault();

            sendMessage();
        }

    });


    /* -----------------------------------------------------
       AUTO FOCUS
       ----------------------------------------------------- */

    setTimeout(function () {

        userInput.focus();

    }, 250);


    scrollToBottom();

});


/* =========================================================
   SEND MESSAGE
   ========================================================= */

async function sendMessage() {

    if (!userInput || isSending) {
        return;
    }


    const message = userInput.value.trim();


    if (!message) {

        userInput.focus();

        return;
    }


    /* -----------------------------------------------------
       LOCK SEND
       ----------------------------------------------------- */

    isSending = true;


    /* -----------------------------------------------------
       ADD USER MESSAGE
       ----------------------------------------------------- */

    addUserMessage(message);


    /* -----------------------------------------------------
       CLEAR INPUT
       ----------------------------------------------------- */

    userInput.value = "";

    userInput.focus();


    /* -----------------------------------------------------
       SHOW TYPING
       ----------------------------------------------------- */

    showTyping();


    try {

        const csrfToken = getCSRFToken();


        const response = await fetch(
            "/chat/",
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/x-www-form-urlencoded; charset=UTF-8",

                    "X-CSRFToken":
                        csrfToken,

                    "X-Requested-With":
                        "XMLHttpRequest"
                },

                body:
                    "message=" +
                    encodeURIComponent(message)
            }
        );


        /* -------------------------------------------------
           RESPONSE ERROR
           ------------------------------------------------- */

        if (!response.ok) {

            throw new Error(
                "Server returned status " + response.status
            );
        }


        /* -------------------------------------------------
           JSON
           ------------------------------------------------- */

        const data = await response.json();


        removeTyping();


        /* -------------------------------------------------
           BOT RESPONSE
           ------------------------------------------------- */

        const botResponse =
            typeof data.response === "string"
                ? data.response
                : "Sorry, I could not understand that question.";


        setTimeout(function () {

            addBotMessage(
                botResponse,
                message
            );

        }, 250);


    } catch (error) {

        console.error(
            "JahanaviAI Error:",
            error
        );


        removeTyping();


        setTimeout(function () {

            addBotMessage(
                "Sorry, something went wrong while connecting to the chatbot. Please try again.",
                message
            );

        }, 250);

    } finally {

        setTimeout(function () {

            isSending = false;

            if (userInput) {
                userInput.focus();
            }

        }, 350);

    }

}


/* =========================================================
   ADD USER MESSAGE
   ========================================================= */

function addUserMessage(message) {

    if (!chatBox) {
        return;
    }


    const row =
        document.createElement("div");

    row.className =
        "message-row user-row";


    const content =
        document.createElement("div");

    content.className =
        "message-content";


    const name =
        document.createElement("div");

    name.className =
        "message-name";

    name.textContent =
        "You";


    const bubble =
        document.createElement("div");

    bubble.className =
        "user-message";


    bubble.innerHTML =
        formatMessage(message);


    content.appendChild(name);

    content.appendChild(bubble);

    row.appendChild(content);


    chatBox.appendChild(row);


    scrollToBottom();

}


/* =========================================================
   ADD BOT MESSAGE
   ========================================================= */

function addBotMessage(
    message,
    question = ""
) {

    if (!chatBox) {
        return;
    }


    const row =
        document.createElement("div");

    row.className =
        "message-row bot-row";


    /* -----------------------------------------------------
       AVATAR
       ----------------------------------------------------- */

    const avatar =
        document.createElement("div");

    avatar.className =
        "message-avatar";

    avatar.textContent =
        "J";


    /* -----------------------------------------------------
       WRAPPER
       ----------------------------------------------------- */

    const wrapper =
        document.createElement("div");

    wrapper.className =
        "message-wrapper";


    /* -----------------------------------------------------
       MESSAGE INFO
       ----------------------------------------------------- */

    const info =
        document.createElement("div");

    info.className =
        "message-info";


    const name =
        document.createElement("strong");

    name.textContent =
        "Jahanavi";


    const role =
        document.createElement("span");

    role.textContent =
        "AI Assistant";


    info.appendChild(name);

    info.appendChild(role);


    /* -----------------------------------------------------
       MESSAGE BUBBLE
       ----------------------------------------------------- */

    const bubble =
        document.createElement("div");

    bubble.className =
        "bot-message";


    bubble.innerHTML =
        formatMessage(message);


    wrapper.appendChild(info);

    wrapper.appendChild(bubble);


    row.appendChild(avatar);

    row.appendChild(wrapper);


    chatBox.appendChild(row);


    /* -----------------------------------------------------
       NEXT QUESTIONS
       ----------------------------------------------------- */

    showNextQuestions(question);


    scrollToBottom();

}


/* =========================================================
   FORMAT MESSAGE
   ========================================================= */

function formatMessage(message) {

    if (!message) {
        return "";
    }


    let safeMessage =
        escapeHTML(message);


    /* -----------------------------------------------------
       BOLD TEXT
       ----------------------------------------------------- */

    safeMessage =
        safeMessage.replace(
            /\*\*(.*?)\*\*/g,
            "<strong>$1</strong>"
        );


    /* -----------------------------------------------------
       LINE BREAKS
       ----------------------------------------------------- */

    safeMessage =
        safeMessage.replace(
            /\r?\n/g,
            "<br>"
        );


    /* -----------------------------------------------------
       BULLET FORMATTING
       ----------------------------------------------------- */

    safeMessage =
        safeMessage.replace(
            /(^|<br>)•\s?/g,
            "$1<span class=\"chat-bullet\">•</span> "
        );


    return safeMessage;

}


/* =========================================================
   SHOW NEXT QUESTIONS
   ========================================================= */

function showNextQuestions(question) {

    if (!chatBox) {
        return;
    }


    const topic =
        detectTopic(question);


    const questions =
        relatedQuestions[topic];


    if (
        !questions ||
        questions.length === 0
    ) {
        return;
    }


    /* -----------------------------------------------------
       BOX
       ----------------------------------------------------- */

    const box =
        document.createElement("div");

    box.className =
        "next-question-box";


    /* -----------------------------------------------------
       TITLE
       ----------------------------------------------------- */

    const title =
        document.createElement("div");

    title.className =
        "next-title";

    title.textContent =
        "Continue learning";


    box.appendChild(title);


    /* -----------------------------------------------------
       OPTIONS
       ----------------------------------------------------- */

    const options =
        document.createElement("div");

    options.className =
        "question-options";


    questions.forEach(function (questionText) {

        const button =
            document.createElement("button");


        button.type =
            "button";


        button.textContent =
            questionText;


        button.addEventListener(
            "click",
            function () {

                sendSuggestion(
                    questionText
                );

            }
        );


        options.appendChild(button);

    });


    box.appendChild(options);


    chatBox.appendChild(box);


    scrollToBottom();

}


/* =========================================================
   DETECT TOPIC
   ========================================================= */

function detectTopic(question) {

    if (!question) {
        return null;
    }


    const text =
        question
            .toLowerCase()
            .trim();


    if (
        text.includes("python") ||
        text.includes("list in python") ||
        text.includes("variable in python") ||
        text.includes("features of python")
    ) {
        return "python";
    }


    if (
        text.includes("generative ai") ||
        text.includes("genai") ||
        text.includes("llm") ||
        text.includes("large language model")
    ) {
        return "generative";
    }


    if (
        text.includes("machine learning") ||
        text.includes("supervised learning") ||
        text.includes("unsupervised learning") ||
        text.includes("reinforcement learning") ||
        text.includes("what is ml")
    ) {
        return "ml";
    }


    if (
        text.includes("django")
    ) {
        return "django";
    }


    if (
        text.includes("database") ||
        text.includes("dbms") ||
        text.includes("mysql") ||
        text.includes("sql")
    ) {
        return "database";
    }


    if (
        text.includes("data science") ||
        text.includes("pandas") ||
        text.includes("numpy") ||
        text.includes("matplotlib")
    ) {
        return "data";
    }


    if (
        text.includes("algorithm") ||
        text.includes("programming") ||
        text.includes("data structure")
    ) {
        return "programming";
    }


    if (
        text.includes("chatbot")
    ) {
        return "chatbot";
    }


    if (
        text.includes("Jahanavi ") ||
        text.includes("mentor") ||
        text.includes("who are you")
    ) {
        return "Jahanavi ";
    }


    if (
        text === "what is ai" ||
        text === "what is artificial intelligence" ||
        text.includes("types of ai") ||
        text.includes("narrow ai")
    ) {
        return "ai";
    }


    return null;

}


/* =========================================================
   SEND SUGGESTION
   ========================================================= */

function sendSuggestion(message) {

    if (!userInput) {
        userInput =
            document.getElementById("user-input");
    }


    if (!userInput) {
        return;
    }


    userInput.value =
        message;


    userInput.focus();


    sendMessage();

}


/* =========================================================
   SHOW TYPING
   ========================================================= */

function showTyping() {

    removeTyping();


    const typing =
        document.getElementById(
            "typing-indicator"
        );


    if (!typing) {
        return;
    }


    typing.style.display =
        "flex";


    scrollToBottom();

}


/* =========================================================
   REMOVE TYPING
   ========================================================= */

function removeTyping() {

    const typing =
        document.getElementById(
            "typing-indicator"
        );


    if (!typing) {
        return;
    }


    typing.style.display =
        "none";

}


/* =========================================================
   CLEAR CHAT
   ========================================================= */

function clearChat() {

    if (!chatBox) {
        chatBox =
            document.getElementById("chat-box");
    }


    if (!chatBox) {
        return;
    }


    chatBox.innerHTML = `

        <div class="welcome">

            <div class="welcome-avatar">
                J
            </div>

            <div class="welcome-content">

                <span class="welcome-small">
                    WELCOME TO YOUR LEARNING SPACE
                </span>

                <h2>
                    What would you like
                    <br>
                    to learn today?
                </h2>

                <p>
                    Ask Jahanavi about Python Artificial Intelligence
                    Machine Learning Django databases and other
                    basic technology concepts.
                </p>

            </div>

        </div>


        <div class="message-row bot-row">

            <div class="message-avatar">
                J
            </div>

            <div class="message-wrapper">

                <div class="message-info">

                    <strong>
                        Jahanavi
                    </strong>

                    <span>
                        AI Assistant
                    </span>

                </div>


                <div class="bot-message">

                    <p>
                        Hi 👋 I'm
                        <strong>Jahanavi</strong>.
                    </p>

                    <p>
                        You can ask me a question or choose
                        any topic below to start learning.
                    </p>

                </div>

            </div>

        </div>


        <div class="topics-section">

            <div class="section-header">

                <div>

                    <h3>
                        Explore Topics
                    </h3>

                    <p>
                        Start with any topic you like
                    </p>

                </div>

            </div>


            <div
                id="question-options"
                class="topic-grid"
            >

                ${createTopicCard(
                    "Py",
                    "python",
                    "Python",
                    "Programming basics",
                    "What is Python?",
                    "what is python",
                    "01"
                )}

                ${createTopicCard(
                    "AI",
                    "ai",
                    "Artificial Intelligence",
                    "AI fundamentals",
                    "What is AI?",
                    "what is ai",
                    "02"
                )}

                ${createTopicCard(
                    "ML",
                    "ml",
                    "Machine Learning",
                    "Models & concepts",
                    "What is ML?",
                    "what is machine learning",
                    "03"
                )}

                ${createTopicCard(
                    "G",
                    "genai",
                    "Generative AI",
                    "Modern AI concepts",
                    "What is GenAI?",
                    "what is generative ai",
                    "04"
                )}

                ${createTopicCard(
                    "Dj",
                    "django",
                    "Django",
                    "Web development",
                    "What is Django?",
                    "what is django",
                    "05"
                )}

                ${createTopicCard(
                    "DB",
                    "database",
                    "Databases",
                    "Data & SQL basics",
                    "What is a Database?",
                    "what is database",
                    "06"
                )}

            </div>

        </div>

    `;


    if (userInput) {
        userInput.value = "";
        userInput.focus();
    }


    removeTyping();


    scrollToBottom();

}


/* =========================================================
   CREATE TOPIC CARD
   ========================================================= */

function createTopicCard(
    icon,
    iconClass,
    title,
    subtitle,
    question,
    suggestion,
    number
) {

    return `

        <button
            class="topic-card"
            onclick="sendSuggestion('${escapeAttribute(suggestion)}')"
            type="button"
        >

            <div class="topic-card-top">

                <div class="topic-icon ${iconClass}">
                    ${icon}
                </div>

                <span class="topic-number">
                    ${number}
                </span>

            </div>


            <div class="topic-card-content">

                <strong>
                    ${title}
                </strong>

                <span>
                    ${subtitle}
                </span>

            </div>


            <div class="topic-card-bottom">

                <span>
                    ${question}
                </span>

                <b>
                    →
                </b>

            </div>

        </button>

    `;

}


/* =========================================================
   SCROLL TO BOTTOM
   ========================================================= */

function scrollToBottom() {

    if (!chatBox) {
        return;
    }


    setTimeout(function () {

        chatBox.scrollTo({
            top: chatBox.scrollHeight,
            behavior: "smooth"
        });

    }, 50);

}


/* =========================================================
   GET CSRF TOKEN
   ========================================================= */

function getCSRFToken() {

    const cookieName =
        "csrftoken";


    const cookies =
        document.cookie
            .split(";");


    for (
        let i = 0;
        i < cookies.length;
        i++
    ) {

        const cookie =
            cookies[i].trim();


        if (
            cookie.startsWith(
                cookieName + "="
            )
        ) {

            return decodeURIComponent(
                cookie.substring(
                    cookieName.length + 1
                )
            );

        }

    }


    /* -----------------------------------------------------
       Try hidden Django input as fallback
       ----------------------------------------------------- */

    const csrfInput =
        document.querySelector(
            "[name=csrfmiddlewaretoken]"
        );


    if (csrfInput) {

        return csrfInput.value;

    }


    return "";

}


/* =========================================================
   ESCAPE HTML
   ========================================================= */

function escapeHTML(value) {

    if (value === null || value === undefined) {
        return "";
    }


    const div =
        document.createElement("div");


    div.textContent =
        String(value);


    return div.innerHTML;

}


/* =========================================================
   ESCAPE ATTRIBUTE
   ========================================================= */

function escapeAttribute(value) {

    if (
        value === null ||
        value === undefined
    ) {
        return "";
    }


    return String(value)
        .replace(/\\/g, "\\\\")
        .replace(/'/g, "\\'")
        .replace(/"/g, "&quot;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}


/* =========================================================
   NORMALIZE QUESTION
   ========================================================= */

function normalizeQuestion(text) {

    if (!text) {
        return "";
    }


    return text
        .toLowerCase()
        .trim()
        .replace(/[?!.,;:]/g, "")
        .replace(/\s+/g, " ");

}


/* =========================================================
   INPUT FOCUS
   ========================================================= */

function focusInput() {

    if (!userInput) {

        userInput =
            document.getElementById(
                "user-input"
            );

    }


    if (userInput) {
        userInput.focus();
    }

}


/* =========================================================
   EXPOSE FUNCTIONS GLOBALLY
   =========================================================

   Required because index.html uses inline
   onclick="sendMessage()" etc.
   ========================================================= */

window.sendMessage =
    sendMessage;


window.sendSuggestion =
    sendSuggestion;


window.clearChat =
    clearChat;


window.focusInput =
    focusInput;


window.showTyping =
    showTyping;


window.removeTyping =
    removeTyping;